#include "Admin.h"
#include<iostream>
#include<cstring>
using namespace std;
Admin::Admin()
{
	strcpy_s(A_id, "A01");
	strcpy_s(Password, "");
	strcpy_s(Name, "");
	strcpy_s(DOB, "");
	strcpy_s(Time, "");
	Age = 40;
	strcpy_s(PhoneNo, "");
}

void Admin::Login(const char aid[], const char password[])
{
	strcpy_s(A_id, aid);
	strcpy_s(Password, password);
}

void Admin::CreateaccountChef()
{
}

void Admin::ViewFeedback()
{
}

void Admin::IncreaseSalaryDeliveryboy()
{
}

void Admin::ViewMonthlyReport()
{
}

Admin::~Admin()
{
	cout << "Destructor is called." << endl;
}
