#pragma once
#include"Delivery.h"
#include"Chef.h"
#include"FoodItem.h"
#include"Feedback.h"
#include"Report.h"

class Admin
{
private:
	char A_id[3];
	char Password[8];
	char Name[10];
	char DOB[10];
	char Time[8];
	int Age;
	char PhoneNo[10];
	Delivery* dv;
	Chef* ch;
	FoodItem* fd;
	Feedback* fb;
	Report* rp;

public:
	Admin();
	void Login(const char aid[], const char password[]);
	void CreateaccountChef();
	void ViewFeedback();
	void IncreaseSalaryDeliveryboy();
	void ViewMonthlyReport();
	~Admin();
};

