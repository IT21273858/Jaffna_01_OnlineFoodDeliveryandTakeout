#include "Chef.h"
#include<iostream>
#include<cstring>
using namespace std;
Chef::Chef()
{
	strcpy_s(Ch_id, "Ch1");
	strcpy_s(Password, "");
	strcpy_s(Name, "");
	strcpy_s(DOB,"");
	Age = 56;
	strcpy_s(Address, "");
	Salary = 0.00;
	strcpy_s(Qualification, "");
	strcpy_s(PhoneNo, "");


}

void Chef::Login(const char ch_id[], const char password[])
{
	strcpy_s(Ch_id, ch_id);
	strcpy_s(Password, password);
}

void Chef::SetDetails(const char ch_id[], const char password[], const char name[], const char dob[], int age, double salary, const char quali[], const char pno[], const char add[])
{
	strcpy_s(Ch_id,ch_id);
	strcpy_s(Password,password);
	strcpy_s(Name,name);
	strcpy_s(DOB,dob);
	Age = age;
	strcpy_s(Address,add);
	Salary = salary;
	strcpy_s(Qualification,quali);
	strcpy_s(PhoneNo,pno);
}

void Chef::ViewAccount()
{
}

void Chef::ViewOrdersplaced()
{
}

void Chef::FoodItem()
{
}

void Chef::PrepareFood()
{
}

Chef::~Chef()
{
	cout << "Destructor is called." << endl;
}
