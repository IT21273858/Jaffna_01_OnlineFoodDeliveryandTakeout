#pragma once
class Chef
{
private:
	char Ch_id[3];
	char Password[8];
	char Name[10];
	char DOB[10];
	int Age;
	double Salary;
	char Qualification[30];
	char PhoneNo[10];
	char Address[50];
public:
	Chef();
	void Login(const char ch_id[], const char password[]);
	void SetDetails(const char ch_id[],const char password[],const char name[],const char dob[],int age,double salary,const char quali[],const char pno[],const char add[]);
	void ViewAccount();
	void ViewOrdersplaced();
	void FoodItem();
	void PrepareFood();
	~Chef();

};

