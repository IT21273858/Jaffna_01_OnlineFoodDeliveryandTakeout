#include "FoodItem.h"
#include<iostream>
#include<cstring>
using namespace std;
FoodItem::FoodItem()
{
	strcpy_s(FD_Id, "F01");
	strcpy_s(Type, "Veg");
	Price = 0.00;
	strcpy_s(Item, "Fish");

}

void FoodItem::SetFoodItem(const char fdid[], const char type[], double price, const char item[])
{
	strcpy_s(FD_Id,fdid);
	strcpy_s(Type,type);
	Price = price;
	strcpy_s(Item, item);
}

void FoodItem::EditPriceofFoodItem(double price)
{
	Price = price;
}

void FoodItem::ViewFoodItem()
{
	cout << Item << endl;
}

void FoodItem::PrepareFood()
{

}

FoodItem::~FoodItem()
{
	cout << "Destructor is called." << endl;
}
