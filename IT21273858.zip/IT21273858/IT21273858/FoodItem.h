#pragma once
#include"Customer.h"
#include"Chef.h"
#include"Order.h"
class FoodItem
{
private:
	char FD_Id[3];
	char Type[8];
	double Price;
	char Item[10];
	Customer* cu;
	Chef* ch;
	Order* od;
public:
	FoodItem();
	void SetFoodItem(const char fdid[], const char type[], double price, const char item[]);
	void EditPriceofFoodItem(double price);
	void ViewFoodItem();
	void PrepareFood();
	~FoodItem();

};

