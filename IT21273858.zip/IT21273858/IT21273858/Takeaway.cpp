#include "Takeaway.h"
#include<iostream>
#include<cstring>
using namespace std;
Takeaway::Takeaway()
{
	Price = 0.00;
	strcpy_s(PhoneNo,"077157945");
}

void Takeaway::SetOrderDetails(double price, const char pno[])
{
	Price =price;
	strcpy_s(PhoneNo, pno);
}

double Takeaway::RetrieveFoodItem()
{
	return 0.0;
}

Takeaway::~Takeaway()
{
	cout << "Destructor is called." << endl;
}
