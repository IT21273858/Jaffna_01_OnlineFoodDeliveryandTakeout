#pragma once
#include"Order.h"
class Takeaway:public Order
{
private:
	double Price;
	char PhoneNo[10];
public:
	Takeaway();
	void SetOrderDetails(double Price, const char pno[]);
	double RetrieveFoodItem();
	~Takeaway();
};

